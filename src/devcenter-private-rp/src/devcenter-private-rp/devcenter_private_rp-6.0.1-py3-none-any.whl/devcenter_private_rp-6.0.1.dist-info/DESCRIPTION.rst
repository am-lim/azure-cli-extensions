# Azure CLI Extension for Microsoft Dev Box and Azure Deployment Environments #

This is the Azure CLI extension for [Microsoft Dev Box](https://learn.microsoft.com/azure/dev-box/) and [Azure Deployment Environments](https://learn.microsoft.com/azure/deployment-environments/)



### How to use ###

Install this extension using the below CLI command

``` sh

az extension add --name devcenter

```



### Usage ###

See [Microsoft Dev Box and Azure Deployment Environments Azure CLI reference](https://learn.microsoft.com/cli/azure/devcenter?view=azure-cli-latest)

 

#### devcenter-private-rp admin ####

Manage admin resources with devcenter

``` sh

az devcenter-private-rp admin

```

#### devcenter dev ####

Manage developer resources with devcenter

``` sh

az devcenter dev

```



### Update ###

Update this extension using the below CLI command

``` sh

az extension update --name devcenter

```

### Uninstall ###

Run `az extension list` to see if the extension is installed.



Run `az --version` to see the current verion of the extension. 



To remove the extension use the below CLI command

``` sh

az extension remove --name devcenter

```

.. :changelog:



Release History

===============

6.0.1

++++++

* Update "az devcenter dev environment show-logs-by-operation" to handle escape characters



6.0.0

++++++

* Update control plane API to v2024-05-01-preview

* Update data plane API to v2024-05-01-preview



5.0.1

++++++

* Fix bug in "az devcenter dev environment show-logs-by-operation" if logs is not in JSON format



5.0.0

++++++

* Require roles and identity type parameters in "az decenter admin project-environment-type create"



4.0.1

++++++

* Update due to bug in API swagger causing missing API version



4.0.0

++++++

* Update control plane API to v2023-10-01-preview

* Update data plane API to v2023-10-01-preview



3.0.0

++++++

* Update control plane API to v2023-06-01-preview

* Update data plane API to v2023-07-01-preview



=======

2.0.0

++++++

* Update dev-box-definition to devbox-definition parameter



1.0.2

++++++

* Update allowPartialScopes to True for ARG query



1.0.1

++++++

* Update error string for environment create same name validation

* Update data plane help to align with control plane



1.0.0

++++++

* Update control plane and data plane APIs to v2023-04-01

* Azure Deployment Environments GA release

* Update to network connection health detail to health check 

* Update delay upcoming action to delay action 



0.1.2

++++++

* Remove hibernate from help example



0.1.1

++++++

* Fix wrong command group name

* Add correct author email



0.1.0

++++++

* Initial release.

